import psutil
import pandas as pd
import matplotlib.pyplot as plt

# Funzione per ottenere l'utilizzo della memoria e del disco per ciascun processo
def get_process_info():
    processes = []
    for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_info']):
        try:
            # Ottenere l'uso della CPU e della memoria
            cpu_usage = proc.info['cpu_percent']
            memory_usage = proc.info['memory_info'].rss / (1024 * 1024)  # Convertire in MB
            processes.append({
                'pid': proc.info['pid'],
                'name': proc.info['name'],
                'cpu_percent': cpu_usage,
                'memory_usage': memory_usage
            })
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue  # Ignorare i processi non accessibili

    return processes

# Passo 1: Ottenere la lista dei processi attivi
processes = get_process_info()

# Passo 2: Creare un DataFrame dai dati dei processi
df = pd.DataFrame(processes)

# Passo 3: Ordinare il DataFrame per utilizzo CPU e tenere i primi 10
df = df.sort_values(by='cpu_percent', ascending=False).head(10)

# Passo 4: Stampare il DataFrame (opzionale)
print(df)

# Passo 5: Creare i grafici
fig, ax1 = plt.subplots(figsize=(12, 8))

# Grafico per l'utilizzo della CPU
ax1.barh(df['name'], df['cpu_percent'], color='skyblue', label='Utilizzo CPU (%)')
ax1.set_xlabel('Utilizzo CPU (%)')
ax1.set_title('Top 10 Processi per Utilizzo CPU e Memoria')

# Creare un secondo asse per la memoria
ax2 = ax1.twinx()
ax2.barh(df['name'], df['memory_usage'], color='orange', alpha=0.5, label='Utilizzo Memoria (MB)')
ax2.set_ylabel('Utilizzo Memoria (MB)')

# Aggiungere le legende
ax1.legend(loc='upper left')
ax2.legend(loc='upper right')
ax1.grid(axis='x')

plt.show()
