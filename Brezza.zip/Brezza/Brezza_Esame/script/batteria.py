import psutil
import matplotlib.pyplot as plt

# Ottieni informazioni sulla batteria
battery = psutil.sensors_battery()
percent = battery.percent

# Visualizza la percentuale
print(f"Percentuale Batteria: {percent}%")

# Crea un grafico a barre
plt.bar(['Percentuale Batteria'], [percent], color='blue')
plt.ylabel('Percentuale (%)')
plt.title('Stato della Batteria')
plt.ylim(0, 100)  # Imposta il limite dell'asse Y
plt.show()