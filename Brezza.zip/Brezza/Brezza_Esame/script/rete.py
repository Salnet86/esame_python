import psutil
import matplotlib.pyplot as plt

def monitor_network():
    # Ottieni le statistiche di rete
    net_io = psutil.net_io_counters()

    # Dati da visualizzare
    labels = ['Byte Inviati', 'Byte Ricevuti']
    values = [net_io.bytes_sent, net_io.bytes_recv]

    # Creazione del grafico
    plt.bar(labels, values, color=['blue', 'orange'])
    plt.title('Traffico di Rete')
    plt.ylabel('Byte')
    plt.show()

if __name__ == "__main__":
    monitor_network()