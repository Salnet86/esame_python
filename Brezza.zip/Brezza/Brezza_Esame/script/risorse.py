import matplotlib.pyplot as plt
import numpy as np
import psutil


CPU = int(psutil.cpu_percent(interval=1))
DISK = int(psutil.disk_usage('/').percent)
MEMORIA = int(psutil.virtual_memory().percent)

y = [CPU, DISK, MEMORIA]
mylabels = ["CPU", "DISCO", "MEMORIA"]


plt.figure(figsize=(8, 6))
plt.pie(y, labels=mylabels, autopct='%1.1f%%', startangle=140)


explode = (0.1, 0, 0) 
plt.pie(y, explode=explode, labels=mylabels, autopct='%1.1f%%', startangle=140)


plt.title("Uso de Recursos del Sistema")


plt.axis('equal')  
plt.show()