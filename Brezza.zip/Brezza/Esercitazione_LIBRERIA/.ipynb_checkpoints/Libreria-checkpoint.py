class Matematica:
    
    def somma(a, b):
        return a + b


    def sottrazione(c, d):
        return c - d
