class AutoIn:
    def __init__(self, nome, cognome, cf, email, password):
        self.cognome = cognome
        self.nome = nome
        self.cf = cf
        self.email = email
        self.password = password

    def getNome(self):
        return self.nome

    def getCognome(self):
        return self.cognome

    def getCF(self):
        return self.cf

    def getEmail(self):
        return self.email

    def getPassword(self):
        return self.password