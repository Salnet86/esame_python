#!/usr/bin/env python3

import cgi
import cgitb
import html

cgitb.enable()

form = cgi.FieldStorage()

# Fetching values with correct field names
cognome = form.getvalue("cognome")
nome = form.getvalue("nome")
cf = form.getvalue("CF")
emailaddress = form.getvalue("emailaddress")
password = form.getvalue("password")

# Print content-type header
print("Content-Type: text/html")
print()  

# Print HTML response
print("<html>")
print("<head>")
print("<title>Login</title>")
print("</head>")
print("<body>")
print("<h3>Resgistrazione</h3>")

if cognome and nome and cf and emailaddress and password: 
    print("<p>Cognome: {}</p>".format(html.escape(cognome)))
    print("<p>Nome: {}</p>".format(html.escape(nome)))
    print("<p>CF: {}</p>".format(html.escape(cf)))
    print("<p>Email Address: {}</p>".format(html.escape(emailaddress)))

    # Prepare file path
    filename = "login.txt"
    
    # Create email and password
    email = f"{cognome.lower()}@picolab.eu"
    dati_ana = [cognome, nome, cf, email]
    password = f"{cf[0].upper()}{cf[1:6].lower()}_0"

    # Write to file securely
    with open(filename, "a") as scrivi:  # Append mode
        scrivi.write(' '.join(dati_ana) + ' ' + password + '\n')  
    
else:
    print("<p style='color:red;'>Regitsrazione e fallita/p>")

print("</body>")
print("</html>")
