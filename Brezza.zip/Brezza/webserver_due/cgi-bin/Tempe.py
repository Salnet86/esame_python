#!/usr/bin/python3
import datetime
import random
import time

def funzioneTemEpoca():
    now = datetime.datetime.now() 
    ts = str(datetime.datetime.timestamp(now))  
    temperatura = str(random.randint(20, 100))  
    umidita = str(random.randint(20, 100))      
    valori = [ts, temperatura, umidita]
    time.sleep(1)  
    print("Content-type:text/html\r\n\r\n")
    print(f"""
    <html>
    <head><title>Temperature e umidita</title></head>
    <body>
    <h1>Temperature e umidita</h1>
    <p>Epoca: {ts}</p>
    <p>Temperature: {temperatura}°C</p>
    <p>HumiditaUmidita: {umidita}%</p>
    </body>
    </html>
    """)

funzioneTemEpoca()
