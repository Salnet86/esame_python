#!/usr/bin/python3
#dos2unix /home/utente/Scrivania/brezza/cgi-bin/temp.py
import datetime
from http.cookies import SimpleCookie
import os
import random
import time



'''
import datetime
import random
import time

def funzioneTemEpoca():
    i = 0
  
    while i < 10: 
        now = datetime.datetime.now() 
        ts = str(datetime.datetime.timestamp(now))  
        temperatura = str(random.randint(20, 100))  
        umidita = str(random.randint(20, 100))      
        valori = [ts, temperatura, umidita]
        risu = ','.join(valori)
        time.sleep(5/100)
        print(valori)
        i += 1
        

funzioneTemEpoca()


'''



'''


def TemperatureUmidita():
    print("Content-type: text/html\r\n")

 


    # Start of HTML content
    print("<html><head><title>Temperature and Humidity</title></head>")
    print("<body>")
    print("<h1 style='text-align:center'>Sito</h1>")
   

    # Table headers
    print("<table style='margin:auto; border:1px solid black; border-collapse: collapse;'>")
    print("<tr><th style='border:1px solid black; padding:8px;'>Epoca</th><th style='border:1px solid black; padding:8px;'>Temperatura</th><th style='border:1px solid black; padding:8px;'>Umidità</th></tr>")

    i = 0
    while i < 10:  # 10 iterations with 5-second sleep each
        now = datetime.datetime.now() 
        ts = datetime.datetime.timestamp(now)
        temperatura = random.randint(20, 100)  
        umidita = random.randint(20, 100)  

       
        print(f"<tr><td style='border:1px solid black; padding:8px;'>{ts}</td><td style='border:1px solid black; padding:8px;'>{temperatura}</td><td style='border:1px solid black; padding:8px;'>{umidita}%</td></tr>")
         
        i += 1

    print("</table>")
    print("</body></html>")
    
TemperatureUmidita()

'''

import datetime
from http.cookies import SimpleCookie
import io
import os
import random
import time
import matplotlib.pyplot as plt
import base64  

def TemperatureUmidita():
 
    print("Content-type: text/html\r\n")
    print("<html><head><title>Temperature and Humidity</title></head>")
    print("<body>")
    print("<h1 style='text-align:center'>Sito</h1>")

    print("<table style='margin:auto; border:1px solid black; border-collapse: collapse;'>")
    print("<tr><th style='border:1px solid black; padding:8px;'>Epoca</th><th style='border:1px solid black; padding:8px;'>Temperatura</th><th style='border:1px solid black; padding:8px;'>Umidità</th></tr>")


    timestamps = []
    temperatures = []
    humidities = []

    i = 0
    while i < 10:  
        now = datetime.datetime.now()
        ts = datetime.datetime.timestamp(now)
        temperatura = random.randint(20, 100)
        umidita = random.randint(20, 100)
        
      
        timestamps.append(ts)
        temperatures.append(temperatura)
        humidities.append(umidita)

     
        print(f"<tr><td style='border:1px solid black; padding:8px;'>{ts}</td><td style='border:1px solid black; padding:8px;'>{temperatura}°C</td><td style='border:1px solid black; padding:8px;'>{umidita}%</td></tr>")
        time.sleep(5/100)
        i += 1

    print("</table>")

    # Plotting
    buffer = io.BytesIO()  
    plt.figure(figsize=(10, 5))
    plt.bar(temperatures, humidities,label="Temperature [°C]", color="blue")
 
    plt.xlabel("umidita")
    plt.ylabel("Temperature")
    plt.title("Temperatura umidita")
    plt.legend()
    plt.grid()
    plt.savefig(buffer, format='png')
    plt.close()
    buffer.seek(0)
    
   
    img_base64 = base64.b64encode(buffer.read()).decode('utf-8')  
    
   
    print("<h2 style='text-align:center'>Temperature and Humidity </h2>")
    print('<div style="text-align:center;">')
    print(f'<img src="data:image/png;base64,{img_base64}">') 
    print('</div>')

    print("</body></html>")

TemperatureUmidita()
