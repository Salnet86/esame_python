import psutil
import pandas as pd
import matplotlib.pyplot as plt

# Funzione per ottenere informazioni sui processi attivi
def get_process_info():
    processes = []
    for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_info']):
        try:
            cpu_usage = proc.info['cpu_percent']
            memory_usage = proc.info['memory_info'].rss / (1024 * 1024)  # Convertire in MB
            processes.append({
                'pid': proc.info['pid'],
                'name': proc.info['name'],
                'cpu_percent': cpu_usage,
                'memory_usage': memory_usage
            })
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue

    return processes

# Passo 1: Ottenere la lista dei processi attivi
processes = get_process_info()

# Passo 2: Creare un DataFrame dai dati dei processi
df = pd.DataFrame(processes)

# Passo 3: Ordinare il DataFrame per utilizzo CPU e tenere i primi 10
df = df.sort_values(by='cpu_percent', ascending=False).head(10)

# Passo 4: Ottenere le statistiche di rete
net_io = psutil.net_io_counters()
network_sent = net_io.bytes_sent / (1024 * 1024)  # Convertire in MB
network_recv = net_io.bytes_recv / (1024 * 1024)  # Convertire in MB

# Passo 5: Creare i grafici
fig, ax1 = plt.subplots(figsize=(12, 8))

# Grafico per l'utilizzo della CPU
ax1.barh(df['name'], df['cpu_percent'], color='skyblue', label='Utilizzo CPU (%)')
ax1.set_xlabel('Utilizzo CPU (%)')
ax1.set_title('Top 10 Processi per Utilizzo CPU e Memoria')

# Creare un secondo asse per la memoria
ax2 = ax1.twinx()
ax2.barh(df['name'], df['memory_usage'], color='orange', alpha=0.5, label='Utilizzo Memoria (MB)')
ax2.set_ylabel('Utilizzo Memoria (MB)')

# Aggiungere le legende
ax1.legend(loc='upper left')
ax2.legend(loc='upper right')
ax1.grid(axis='x')

# Mostrare i grafici
plt.show()

# Passo 6: Mostrare le statistiche di rete
plt.figure(figsize=(10, 5))
plt.bar(['Inviati', 'Ricevuti'], [network_sent, network_recv], color=['blue', 'green'])
plt.title('Utilizzo della Rete Totale (MB)')
plt.ylabel('Bytes (MB)')
plt.grid(axis='y')

# Mostrare il grafico di rete
plt.show()
