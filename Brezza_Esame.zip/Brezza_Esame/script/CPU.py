import psutil
import time
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

for i in range(10):
    df=pd.DataFrame([[f"{psutil.cpu_percent(interval=1)}",f"{psutil.disk_usage('/').percent}%",f"{psutil.virtual_memory().percent}%"]],columns=['CPU','DISK','MEMORIA'])
    print(df)




