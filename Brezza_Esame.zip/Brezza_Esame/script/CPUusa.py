import psutil
import pandas as pd
import time
import matplotlib.pyplot as plt


def get_cpu_temperature():
    try:
        # On Linux systems, this typically works:
        temps = psutil.sensors_temperatures()
        return temps['coretemp'][0].current if 'coretemp' in temps else None
    except Exception as e:
        print("Could not read CPU temperature:", e)
        return None


cpu_usage = []
cpu_temp = []


for i in range(10):
    cpu_usage.append(psutil.cpu_percent(interval=1))
    temp = get_cpu_temperature()
    cpu_temp.append(temp if temp is not None else 0)  # Handle cases where temp is unavailable


df = pd.DataFrame({
    'CPU Usage (%)': cpu_usage,
    'CPU Temperature (°C)': cpu_temp
})


print(df)

# Plotting the data
plt.figure(figsize=(10, 5))
plt.subplot(2, 1, 1)
plt.plot(df['CPU Usage (%)'], marker='o', label='CPU Usage (%)')
plt.title('CPU Usage Over Time')
plt.ylabel('CPU Usage (%)')
plt.grid()

plt.subplot(2, 1, 2)
plt.plot(df['CPU Temperature (°C)'], marker='o', color='orange', label='CPU Temperature (°C)')
plt.title('CPU Temperature Over Time')
plt.ylabel('CPU Temperature (°C)')
plt.grid()

plt.tight_layout()
plt.show()