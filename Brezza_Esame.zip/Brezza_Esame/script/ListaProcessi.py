import psutil
import pandas as pd
import matplotlib.pyplot as plt

# Passo 1: Ottenere la lista dei processi attivi
processes = []
for proc in psutil.process_iter(['pid', 'name', 'cpu_percent']):
    try:
        processes.append(proc.info)  # Aggiungere info del processo alla lista
    except (psutil.NoSuchProcess, psutil.AccessDenied):
        continue  # Ignorare i processi non accessibili

# Passo 2: Creare un DataFrame dai dati dei processi
df = pd.DataFrame(processes)

# Passo 3: Ordinare il DataFrame per utilizzo CPU e tenere i primi 10
df = df.sort_values(by='cpu_percent', ascending=False).head(10)

# Passo 4: Stampare il DataFrame (opzionale)
print(df)

# Passo 5: Creare il grafico
plt.figure(figsize=(10, 6))

# Colorare le barre in modo diverso
colors = ['#FF5733', '#33FF57', '#3357FF', '#FF33A8', '#FFD733', '#FF8333', '#33FFF7', '#F733FF', '#F7FF33', '#3375FF']
plt.barh(df['name'], df['cpu_percent'], color=colors)  # Grafico a barre orizzontali

plt.xlabel('Utilizzo CPU (%)')
plt.title('Top 10 Processi per Utilizzo CPU (%)', fontsize=16)
plt.grid(axis='x')  # Aggiungere la griglia per una lettura più facile

# Aggiungere etichette ai valori
for index, value in enumerate(df['cpu_percent']):
    plt.text(value, index, f'{value}%', va='center')

plt.show()