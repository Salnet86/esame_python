import matplotlib.pyplot as plt
import psutil


CONTEGGI = psutil.cpu_count()
CPU = int(psutil.cpu_percent(interval=1))


y = [CPU, CONTEGGI]
mylabels = ["Uso CPU (%)", "Numero di Core CPU"]


plt.figure(figsize=(8, 6))
plt.pie(y, labels=mylabels, autopct='%1.1f%%', startangle=140)


plt.title("Utilizzo delle Risorse CPU")


plt.axis('equal')


plt.show()
