import matplotlib.pyplot as plt
import psutil
import time

# Liste per memorizzare i dati
cpu_usage = []
disk_usage = []
memory_usage = []

# Raccolta dati per 10 secondi
for _ in range(10):
    CPU = int(psutil.cpu_percent(interval=1))
    DISK = int(psutil.disk_usage('/').percent)
    MEMORIA = int(psutil.virtual_memory().percent)
    
    cpu_usage.append(CPU)
    disk_usage.append(DISK)
    memory_usage.append(MEMORIA)

# Calcolo della media
avg_cpu = sum(cpu_usage) / len(cpu_usage)
avg_disk = sum(disk_usage) / len(disk_usage)
avg_memory = sum(memory_usage) / len(memory_usage)

# Dati per il grafico
y = [avg_cpu, avg_disk, avg_memory]
mylabels = ["CPU", "DISCO", "MEMORIA"]

# Creazione del grafico a torta
plt.figure(figsize=(8, 6))
plt.pie(y, labels=mylabels, autopct='%1.1f%%', startangle=140)
plt.title("Utilizzo Medio delle Risorse dopo 10 Iterazioni")
plt.axis('equal')  # Assicura che il grafico sia un cerchio

# Mostra il grafico
plt.show()