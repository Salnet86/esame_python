import psutil
import pandas as pd


cpu_usage = []
disk_usage = []
memory_usage = []

for i in range(10):
    cpu_usage.append(psutil.cpu_percent(interval=1))
    disk_usage.append(psutil.disk_usage('/').percent)
    memory_usage.append(psutil.virtual_memory().percent)


df = pd.DataFrame({
    'CPU': cpu_usage,
    'DISK': disk_usage,
    'MEMORIA': memory_usage
})


print(df)


df.plot(title='System Resource Usage Over Time', figsize=(10, 5))
plt.xlabel('Time (seconds)')
plt.ylabel('Percentage (%)')
plt.legend(['CPU Usage', 'Disk Usage', 'Memory Usage'])
plt.grid()
plt.show()
