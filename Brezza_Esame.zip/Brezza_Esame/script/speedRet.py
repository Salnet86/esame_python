import psutil
import time

# Funzione principale per il monitoraggio
print("Monitoraggio della velocità di upload e download. Premi Ctrl+C per fermare.")
sent_prev = psutil.net_io_counters().bytes_sent
recv_prev = psutil.net_io_counters().bytes_recv

try:
    while True:
        # Attendi un secondo
        time.sleep(1)

        # Ottieni i dati attuali
        net_io = psutil.net_io_counters()
        
        # Calcola i byte inviati e ricevuti dall'ultima misurazione
        sent = net_io.bytes_sent - sent_prev
        recv = net_io.bytes_recv - recv_prev

        # Converti in Mbps (megabit per secondo)
        upload_speed = (sent * 8) / (1024 * 1024)  # Converti byte a megabit
        download_speed = (recv * 8) / (1024 * 1024)

        # Stampa i risultati
        print(f"Upload: {upload_speed:.2f} Mbps, Download: {download_speed:.2f} Mbps")
        
        # Aggiorna i valori precedenti
        sent_prev = net_io.bytes_sent
        recv_prev = net_io.bytes_recv

except KeyboardInterrupt:
    print("\nMonitoraggio interrotto.")
